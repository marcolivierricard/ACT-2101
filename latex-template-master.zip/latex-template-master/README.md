# latex-template
Here are some LaTeX templates I've created.


# Content
* Cheatsheet template
* LaTeX preamble template for general usage
* Cheatsheets for actuarial course (see `act-cheatsheet/` folder)
* **NEW** : Makefile template to combine R (via `Sweave`) and LaTeX easily through your IDE.



